import { useState, useEffect } from "react";
import { supabase } from "../services/supabase";

const initialForm = {
  client_id: "",
  unit_id: "",
  patrimonio_codigo: "",
  tipo: "",
  capacidade: "",
  agente: "",
  localizacao: "",
  setor: "",
  fabricacao: "",
  validade: "",
  ultima_manutencao: "",
  proxima_manutencao: "",
  status: "ativo",
  observacoes: "",
};

export default function ExtintorForm({ onSuccess, onCancel }) {
  const [clientes, setClientes] = useState([]);
  const [units, setUnits] = useState([]);
  const [companyId, setCompanyId] = useState(null);
  const [form, setForm] = useState(initialForm);
  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState("");

  useEffect(() => {
    async function loadInitialData() {
      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session?.user) return;
      const { data: profile } = await supabase
        .from("profiles")
        .select("company_id")
        .eq("id", session.user.id)
        .single();
      if (profile?.company_id) {
        setCompanyId(profile.company_id);

        const { data: clients } = await supabase
          .from("clients")
          .select("id, name")
          .eq("company_id", profile.company_id)
          .order("name", { ascending: true });

        setClientes(clients || []);
      }
    }
    loadInitialData();
  }, []);

  useEffect(() => {
    async function loadUnits() {
      if (!form.client_id) {
        setUnits([]);
        return;
      }
      const { data: unitsData } = await supabase
        .from("units")
        .select("id, name")
        .eq("client_id", form.client_id)
        .order("name", { ascending: true });
      const nextUnits = unitsData || [];
      setUnits(nextUnits);
      setForm((prev) => ({
        ...prev,
        unit_id: nextUnits.length === 1 ? nextUnits[0].id : prev.unit_id,
      }));
    }
    loadUnits();
  }, [form.client_id]);

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (name === "client_id") {
      setForm((prev) => ({ ...prev, unit_id: "" })); // Limpa unidade ao trocar cliente
    }

    if (erro) setErro("");
    if (sucesso) setSucesso("");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setErro("");
    setSucesso("");
    setLoading(true);

    if (!form.client_id) {
      setErro("Selecione o cliente.");
      setLoading(false);
      return;
    }

    if (!companyId) {
      setErro("Empresa não identificada.");
      setLoading(false);
      return;
    }

    if (!form.patrimonio_codigo.trim()) {
      setErro("Informe o patrimônio / código.");
      setLoading(false);
      return;
    }

    if (!form.tipo.trim()) {
      setErro("Informe o tipo do extintor.");
      setLoading(false);
      return;
    }

    if (!form.localizacao.trim()) {
      setErro("Informe a localização do extintor.");
      setLoading(false);
      return;
    }

    const payload = {
      company_id: companyId,
      client_id: form.client_id,
      unit_id: form.unit_id || null,
      internal_code: form.patrimonio_codigo.trim(),
      extinguisher_type: form.tipo.trim(),
      capacity: form.capacidade.trim() || null,
      agent: form.agente.trim() || null,
      location_description: form.localizacao.trim(),
      sector: form.setor.trim() || null,
      manufacture_date: form.fabricacao || null,
      load_expiration_date: form.validade || null,
      hydrostatic_test_date: form.ultima_manutencao || null,
      next_inspection_due: form.proxima_manutencao || null,
      status: form.status || "ativo",
      notes: form.observacoes.trim() || null,
    };

    const { error } = await supabase.from("extinguishers").insert([payload]);

    setLoading(false);

    if (error) {
      setErro("Não foi possível cadastrar o extintor. " + error.message);
      return;
    }

    setSucesso("Extintor cadastrado com sucesso!");
    setForm(initialForm);

    setTimeout(() => {
      if (onSuccess) onSuccess("listarExtintores");
    }, 1200);
  }

  return (
    <div style={styles.shell}>
      <div style={styles.card}>
        <div style={styles.header}>
          <div>
            <h2 style={styles.title}>Cadastrar extintor</h2>
            <p style={styles.subtitle}>
              Preencha os dados do equipamento para manter o controle de inspeções.
            </p>
          </div>

          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              style={styles.closeButton}
              disabled={loading}
            >
              Fechar
            </button>
          )}
        </div>

        {(erro || sucesso) && (
          <div
            style={{
              ...styles.alert,
              ...(erro ? styles.alertError : styles.alertSuccess),
            }}
          >
            {erro || sucesso}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={styles.grid}>
            <div style={{ ...styles.field, gridColumn: "1 / -1" }}>
              <label style={styles.label}>Cliente</label>
              <select
                name="client_id"
                value={form.client_id}
                onChange={handleChange}
                style={styles.input}
                required
              >
                <option value="">Selecione um cliente</option>
                {clientes.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            {form.client_id && (
              <div style={{ ...styles.field, gridColumn: "1 / -1" }}>
                <label style={styles.label}>Unidade</label>
                <select
                  name="unit_id"
                  value={form.unit_id}
                  onChange={handleChange}
                  style={styles.input}
                  required
                >
                  <option value="">Selecione a unidade</option>
                  {units.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name}
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div style={styles.field}>
              <label style={styles.label}>Patrimônio / Código</label>
              <input
                name="patrimonio_codigo"
                value={form.patrimonio_codigo}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: EXT-001"
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Tipo</label>
              <input
                name="tipo"
                value={form.tipo}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: PQS"
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Capacidade</label>
              <input
                name="capacidade"
                value={form.capacidade}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: 6kg"
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Agente</label>
              <input
                name="agente"
                value={form.agente}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: Pó químico seco"
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Localização</label>
              <input
                name="localizacao"
                value={form.localizacao}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: Corredor principal"
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Setor</label>
              <input
                name="setor"
                value={form.setor}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: Administrativo"
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Data de fabricação</label>
              <input
                type="date"
                name="fabricacao"
                value={form.fabricacao}
                onChange={handleChange}
                style={styles.input}
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Validade</label>
              <input
                type="date"
                name="validade"
                value={form.validade}
                onChange={handleChange}
                style={styles.input}
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Última manutenção</label>
              <input
                type="date"
                name="ultima_manutencao"
                value={form.ultima_manutencao}
                onChange={handleChange}
                style={styles.input}
              />
            </div>

            <div style={styles.field}>
              <label style={styles.label}>Próxima manutenção</label>
              <input
                type="date"
                name="proxima_manutencao"
                value={form.proxima_manutencao}
                onChange={handleChange}
                style={styles.input}
              />
            </div>

            <div style={{ ...styles.field, gridColumn: "1 / -1" }}>
              <label style={styles.label}>Status</label>
              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                style={styles.input}
              >
                <option value="ativo">Ativo</option>
                <option value="inativo">Inativo</option>
                <option value="manutencao">Manutenção</option>
                <option value="vencido">Vencido</option>
              </select>
            </div>

            <div style={{ ...styles.field, gridColumn: "1 / -1" }}>
              <label style={styles.label}>Observações</label>
              <textarea
                name="observacoes"
                value={form.observacoes}
                onChange={handleChange}
                style={styles.textarea}
                placeholder="Informações adicionais do extintor"
              />
            </div>
          </div>

          <div style={styles.actions}>
            <button type="submit" style={styles.primaryButton} disabled={loading}>
              {loading ? "Salvando..." : "Salvar extintor"}
            </button>

            <button
              type="button"
              style={styles.secondaryButton}
              onClick={onCancel}
              disabled={loading}
            >
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

const baseInput = {
  width: "100%",
  boxSizing: "border-box",
  padding: "13px 14px",
  borderRadius: "12px",
  border: "1px solid #CBD5E1",
  background: "#FFFFFF",
  color: "#0F172A",
  fontSize: "14px",
  outline: "none",
  boxShadow: "none",
  appearance: "none",
};

const styles = {
  shell: {
    width: "100%",
    padding: "0",
    margin: 0,
    fontFamily: "Inter, sans-serif",
  },

  card: {
    width: "100%",
    maxWidth: "100%",
    background: "#FFFFFF",
    borderRadius: "20px",
    padding: "28px",
    boxShadow: "0 12px 32px rgba(15, 23, 42, 0.08)",
    border: "1px solid #E2E8F0",
  },

  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: "16px",
    marginBottom: "20px",
  },

  title: {
    margin: 0,
    fontSize: "30px",
    fontWeight: "700",
    color: "#0F172A",
  },

  subtitle: {
    margin: "8px 0 0 0",
    fontSize: "14px",
    color: "#64748B",
    lineHeight: 1.5,
  },

  closeButton: {
    border: "none",
    background: "#F1F5F9",
    color: "#0F172A",
    padding: "11px 16px",
    borderRadius: "12px",
    fontWeight: "600",
    cursor: "pointer",
    whiteSpace: "nowrap",
  },

  alert: {
    marginBottom: "18px",
    padding: "14px 16px",
    borderRadius: "12px",
    fontSize: "14px",
    fontWeight: "500",
  },

  alertError: {
    background: "#FEF2F2",
    border: "1px solid #FECACA",
    color: "#B91C1C",
  },

  alertSuccess: {
    background: "#F0FDF4",
    border: "1px solid #BBF7D0",
    color: "#15803D",
  },

  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "18px",
  },

  field: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
    minWidth: 0,
  },

  label: {
    fontSize: "13px",
    fontWeight: "600",
    color: "#334155",
  },

  input: {
    ...baseInput,
    minHeight: "48px",
  },

  textarea: {
    ...baseInput,
    minHeight: "130px",
    resize: "vertical",
    fontFamily: "Inter, sans-serif",
  },

  actions: {
    display: "flex",
    gap: "12px",
    marginTop: "22px",
  },

  primaryButton: {
    flex: 1,
    border: "none",
    background: "#22C55E",
    color: "#FFFFFF",
    padding: "14px 18px",
    borderRadius: "12px",
    fontWeight: "700",
    fontSize: "15px",
    cursor: "pointer",
  },

  secondaryButton: {
    flex: 1,
    border: "none",
    background: "#E2E8F0",
    color: "#0F172A",
    padding: "14px 18px",
    borderRadius: "12px",
    fontWeight: "700",
    fontSize: "15px",
    cursor: "pointer",
  },
};
