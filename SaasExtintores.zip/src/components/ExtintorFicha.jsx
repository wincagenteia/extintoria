import { useEffect, useState } from "react";
import { supabase } from "../services/supabase";

function formatDateForInput(value) {
  if (!value) return "";
  if (typeof value === "string" && value.length >= 10) {
    return value.slice(0, 10);
  }
  return "";
}

export default function ExtintorFicha({ extintor, onClose, onUpdate }) {
  const [form, setForm] = useState({
    internal_code: "",
    extinguisher_type: "",
    capacity: "",
    agent: "",
    location_description: "",
    sector: "",
    manufacture_date: "",
    load_expiration_date: "",
    hydrostatic_test_date: "",
    next_inspection_due: "",
    status: "ativo",
    notes: "",
  });

  const [loading, setLoading] = useState(false);
  const [erro, setErro] = useState("");
  const [sucesso, setSucesso] = useState("");

  useEffect(() => {
    if (!extintor) return;

    setForm({
      internal_code: extintor.internal_code || "",
      extinguisher_type: extintor.extinguisher_type || "",
      capacity: extintor.capacity || "",
      agent: extintor.agent || "",
      location_description: extintor.location_description || "",
      sector: extintor.sector || "",
      manufacture_date: formatDateForInput(extintor.manufacture_date),
      load_expiration_date: formatDateForInput(extintor.load_expiration_date),
      hydrostatic_test_date: formatDateForInput(extintor.hydrostatic_test_date),
      next_inspection_due: formatDateForInput(extintor.next_inspection_due),
      status: extintor.status || "ativo",
      notes: extintor.notes || "",
    });
  }, [extintor]);

  function handleChange(e) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));

    if (erro) setErro("");
    if (sucesso) setSucesso("");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setErro("");
    setSucesso("");
    setLoading(true);

    if (!form.internal_code.trim()) {
      setErro("Informe o patrimônio / código.");
      setLoading(false);
      return;
    }

    if (!form.extinguisher_type.trim()) {
      setErro("Informe o tipo do extintor.");
      setLoading(false);
      return;
    }

    if (!form.location_description.trim()) {
      setErro("Informe a localização do extintor.");
      setLoading(false);
      return;
    }

    const payload = {
      internal_code: form.internal_code.trim(),
      extinguisher_type: form.extinguisher_type.trim(),
      capacity: form.capacity.trim() || null,
      agent: form.agent.trim() || null,
      location_description: form.location_description.trim(),
      sector: form.sector.trim() || null,
      manufacture_date: form.manufacture_date || null,
      load_expiration_date: form.load_expiration_date || null,
      hydrostatic_test_date: form.hydrostatic_test_date || null,
      next_inspection_due: form.next_inspection_due || null,
      status: form.status || "ativo",
      notes: form.notes.trim() || null,
    };

    const { error } = await supabase
      .from("extinguishers")
      .update(payload)
      .eq("id", extintor.id);

    setLoading(false);

    if (error) {
      if (error.message?.includes("extinguishers_company_internal_code_unique")) {
        setErro("Já existe um extintor cadastrado com esse patrimônio / código.");
      } else {
        setErro("Não foi possível atualizar o extintor. " + error.message);
      }
      return;
    }

    setSucesso("Extintor atualizado com sucesso!");

    setTimeout(() => {
      if (onUpdate) onUpdate();
    }, 1000);
  }

  return (
    <div style={styles.shell}>
      <div style={styles.container}>
        <div style={styles.header}>
          <div>
            <h2 style={styles.title}>Ficha do Extintor</h2>
            <p style={styles.subtitle}>
              Visualize e edite os dados do equipamento.
            </p>
          </div>

          <button
            type="button"
            style={styles.closeTopButton}
            onClick={onClose}
            disabled={loading}
          >
            Fechar
          </button>
        </div>

        {(erro || sucesso) && (
          <div
            style={{
              ...styles.feedbackAlert,
              ...(erro ? styles.feedbackError : styles.feedbackSuccess),
            }}
          >
            {erro || sucesso}
          </div>
        )}

        <form style={styles.form} onSubmit={handleSubmit}>
          <div style={styles.grid}>
            <div style={styles.inputGroup}>
              <label style={styles.label}>Patrimônio / Código</label>
              <input
                name="internal_code"
                value={form.internal_code}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: EXT-001"
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Tipo</label>
              <input
                name="extinguisher_type"
                value={form.extinguisher_type}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: PQS"
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Capacidade</label>
              <input
                name="capacity"
                value={form.capacity}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: 6kg"
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Agente</label>
              <input
                name="agent"
                value={form.agent}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: Pó químico seco"
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Localização</label>
              <input
                name="location_description"
                value={form.location_description}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: Corredor principal"
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Setor</label>
              <input
                name="sector"
                value={form.sector}
                onChange={handleChange}
                style={styles.input}
                placeholder="Ex: Administrativo"
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Data de fabricação</label>
              <input
                type="date"
                name="manufacture_date"
                value={form.manufacture_date}
                onChange={handleChange}
                style={styles.input}
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Validade</label>
              <input
                type="date"
                name="load_expiration_date"
                value={form.load_expiration_date}
                onChange={handleChange}
                style={styles.input}
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Última manutenção</label>
              <input
                type="date"
                name="hydrostatic_test_date"
                value={form.hydrostatic_test_date}
                onChange={handleChange}
                style={styles.input}
              />
            </div>

            <div style={styles.inputGroup}>
              <label style={styles.label}>Próxima manutenção</label>
              <input
                type="date"
                name="next_inspection_due"
                value={form.next_inspection_due}
                onChange={handleChange}
                style={styles.input}
              />
            </div>

            <div style={{ ...styles.inputGroup, gridColumn: "1 / -1" }}>
              <label style={styles.label}>Status</label>
              <select
                name="status"
                value={form.status}
                onChange={handleChange}
                style={styles.input}
              >
                <option value="ativo">Ativo</option>
                <option value="inativo">Inativo</option>
                <option value="manutencao">Manutenção</option>
                <option value="vencido">Vencido</option>
              </select>
            </div>

            <div style={{ ...styles.inputGroup, gridColumn: "1 / -1" }}>
              <label style={styles.label}>Observações</label>
              <textarea
                name="notes"
                value={form.notes}
                onChange={handleChange}
                style={styles.textarea}
                placeholder="Informações adicionais do extintor"
              />
            </div>
          </div>

          <div style={styles.btnRow}>
            <button type="submit" style={styles.button} disabled={loading}>
              {loading ? "Salvando..." : "Salvar alterações"}
            </button>

            <button
              type="button"
              style={styles.buttonSecondary}
              onClick={onClose}
              disabled={loading}
            >
              Fechar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

const baseFieldStyle = {
  width: "100%",
  padding: "12px 14px",
  borderRadius: "10px",
  border: "1px solid #CBD5E1",
  fontSize: "14px",
  background: "#FFFFFF",
  color: "#0F172A",
  outline: "none",
  boxSizing: "border-box",
  WebkitTextFillColor: "#0F172A",
};

const styles = {
  shell: {
    width: "100%",
    fontFamily: "Inter, sans-serif",
  },

  container: {
    background: "#fff",
    borderRadius: "20px",
    boxShadow: "0 15px 40px rgba(0,0,0,0.10)",
    padding: "32px 24px",
    maxWidth: "1000px",
    margin: "0 auto",
    width: "100%",
    display: "flex",
    flexDirection: "column",
    gap: "18px",
    border: "1px solid #E2E8F0",
    boxSizing: "border-box",
  },

  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: "16px",
    flexWrap: "wrap",
  },

  title: {
    fontSize: "32px",
    fontWeight: "700",
    color: "#0F172A",
    margin: 0,
  },

  subtitle: {
    fontSize: "14px",
    color: "#64748B",
    margin: "8px 0 0 0",
  },

  closeTopButton: {
    padding: "12px 16px",
    border: "none",
    borderRadius: "10px",
    background: "#E2E8F0",
    color: "#0F172A",
    fontSize: "14px",
    fontWeight: "600",
    cursor: "pointer",
  },

  form: {
    display: "flex",
    flexDirection: "column",
    gap: "18px",
    width: "100%",
  },

  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "18px",
    width: "100%",
  },

  inputGroup: {
    display: "flex",
    flexDirection: "column",
    gap: "6px",
    minWidth: 0,
  },

  label: {
    fontSize: "13px",
    color: "#334155",
    fontWeight: "600",
    marginBottom: "2px",
  },

  input: {
    ...baseFieldStyle,
    minHeight: "48px",
  },

  textarea: {
    ...baseFieldStyle,
    minHeight: "120px",
    resize: "vertical",
    fontFamily: "Inter, sans-serif",
  },

  btnRow: {
    display: "flex",
    gap: "12px",
    marginTop: "10px",
    width: "100%",
  },

  button: {
    width: "100%",
    padding: "14px",
    border: "none",
    borderRadius: "10px",
    background: "#1DB954",
    color: "white",
    fontSize: "15px",
    fontWeight: "600",
    cursor: "pointer",
    transition: "0.2s",
  },

  buttonSecondary: {
    width: "100%",
    padding: "14px",
    border: "none",
    borderRadius: "10px",
    background: "#E2E8F0",
    color: "#0F172A",
    fontSize: "15px",
    fontWeight: "600",
    cursor: "pointer",
    transition: "0.2s",
  },

  feedbackAlert: {
    padding: "14px 16px",
    borderRadius: "12px",
    fontSize: "14px",
    fontWeight: "500",
    lineHeight: 1.5,
  },

  feedbackError: {
    background: "#FEF2F2",
    border: "1px solid #FECACA",
    color: "#B91C1C",
  },

  feedbackSuccess: {
    background: "#F0FDF4",
    border: "1px solid #BBF7D0",
    color: "#15803D",
  },
};