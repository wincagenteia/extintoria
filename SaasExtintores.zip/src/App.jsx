import { useEffect, useState } from "react";
import { supabase } from "./services/supabase";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import ForcePasswordReset from "./pages/ForcePasswordReset";

export default function App() {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [checkingSession, setCheckingSession] = useState(true);

  useEffect(() => {
    let active = true;

    async function loadProfile(authUser) {
      if (!authUser) {
        if (active) {
          setProfile(null);
        }
        return null;
      }

      try {
        const { data: profileData, error } = await supabase
          .from("profiles")
          .select("id, company_id, role, is_active, name")
          .eq("id", authUser.id)
          .maybeSingle();

        if (error) {
          console.error("Erro ao carregar perfil:", error.message);
        }

        const nextProfile = profileData ?? null;

        if (nextProfile && nextProfile.is_active === false) {
          await supabase.auth.signOut();

          if (active) {
            setUser(null);
            setProfile(null);
          }

          return null;
        }

        const normalizedProfile = nextProfile
          ? {
              ...nextProfile,
              must_change_password: authUser?.user_metadata?.must_change_password === true,
            }
          : null;

        if (active) {
          setProfile(normalizedProfile);
        }

        return normalizedProfile;
      } catch (error) {
        console.error("Erro inesperado ao carregar perfil:", error);

        if (active) {
          setProfile(null);
        }

        return null;
      }
    }

    async function bootstrapSession() {
      try {
        const {
          data: { session },
        } = await supabase.auth.getSession();

        const authUser = session?.user ?? null;

        if (active) {
          setUser(authUser);
        }

        await loadProfile(authUser);

        if (active) {
          setCheckingSession(false);
        }
      } catch (error) {
        console.error("Erro ao carregar sess?o:", error);

        if (active) {
          setUser(null);
          setProfile(null);
          setCheckingSession(false);
        }
      }
    }

    bootstrapSession();

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      if (!active) return;

      if (event === "SIGNED_OUT") {
        setUser(null);
        setProfile(null);
        setCheckingSession(false);
        return;
      }

      const authUser = session?.user ?? null;
      setUser(authUser);
      void (async () => {
        await loadProfile(authUser);
        if (active) {
          setCheckingSession(false);
        }
      })();
    });

    return () => {
      active = false;
      subscription.unsubscribe();
    };
  }, []);

  async function handleLogout() {
    try {
      await supabase.auth.signOut();
    } finally {
      setUser(null);
      setProfile(null);
      setCheckingSession(false);
    }
  }

  if (checkingSession) {
    return <div style={{ padding: 30 }}>Carregando...</div>;
  }

  if (user && profile?.must_change_password) {
    return (
      <ForcePasswordReset
        onCompleted={async () => {
          await supabase.auth.refreshSession();
          const {
            data: { session },
          } = await supabase.auth.getSession();

          if (!session?.user) {
            setUser(null);
            setProfile(null);
            return;
          }

          setUser(session.user);
          setProfile((prev) => (prev ? { ...prev, must_change_password: false } : prev));
        }}
      />
    );
  }

  return user ? (
    <Dashboard user={user} profile={profile} onLogout={handleLogout} />
  ) : (
    <Login onLogin={setUser} />
  );
}
